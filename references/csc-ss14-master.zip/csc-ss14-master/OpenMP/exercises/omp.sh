k0ne:exercises jomo$ gfortran -o ex0 -fopenmp ex0.f90
k0ne:exercises jomo$ export OMP_NUM_THREADS=4
k0ne:exercises jomo$ ./ex0 
 Hello world by           0
 Hello world by           1
 Hello world by           3
 Hello world by           2

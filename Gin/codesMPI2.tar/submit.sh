#!/bin/bash
#
#  Name of the job (used to build the name of the standard output stream)
#$ -N myjob
#
#  Number of MPI task requested
#$ -pe orte 24
#
#  The job is located in the current working directory
#$ -cwd
#
#  Merge standard error and standard output streams
#$ -j y

mpirun -display-map ./a.out;

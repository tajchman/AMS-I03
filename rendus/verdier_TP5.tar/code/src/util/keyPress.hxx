void keyPress(const char *s);

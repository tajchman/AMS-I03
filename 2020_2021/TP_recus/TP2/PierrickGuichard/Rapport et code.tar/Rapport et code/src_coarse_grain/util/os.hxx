#ifndef _OS_HXX
#define _OS_HXX

#include <sys/stat.h>

int mkdir_p(const char *path);

#endif

// pause de n millisecondes
void pause(int n);

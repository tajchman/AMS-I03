#ifdef __cplusplus
extern "C"
#endif
int get_memory_usage_kb(long* vmrss_kb, long* vmsize_kb);


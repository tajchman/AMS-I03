Code de resolution approchée de l'equation de la chaleur

Version MPI

_____________________
Pour compiler

./build.py

_____________________
Pour exécuter sur 3 processus MPI

mpirun -n 3 ./install/Release/PoissonMPI

ou :

python run.py -n 3

ou (sur gin.ensta.fr) :

python submit.py -n 3

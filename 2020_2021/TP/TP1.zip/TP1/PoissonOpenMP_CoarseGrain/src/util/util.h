#ifdef __cplusplus
extern "C"
#endif
void affiche(int n, double d);

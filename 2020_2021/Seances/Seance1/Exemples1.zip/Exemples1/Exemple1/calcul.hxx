#include <vector>

void calcul(std::vector<double> & v, const std::vector<double> & u);

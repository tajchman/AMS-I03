#include <vector>

void init(std::vector<double> &v, double v0);

#include <vector>

void calcul1(std::vector<double> &u, 
             std::vector<double> &v, 
             std::vector<double> &w, 
             std::vector<double> &a, 
             std::vector<double> &b, 
             std::vector<double> &c, 
             std::vector<double> &d);

void calcul2(std::vector<double> &u, 
             std::vector<double> &v, 
             std::vector<double> &w, 
             std::vector<double> &a, 
             std::vector<double> &b, 
             std::vector<double> &c, 
             std::vector<double> &d);


#include <vector>

void calcul1(std::vector<double> &y, 
             double a, 
             const std::vector<double> &x,
             double b); 

void calcul2(std::vector<double> &y, 
             double a, 
             const std::vector<double> &x,
             double b); 


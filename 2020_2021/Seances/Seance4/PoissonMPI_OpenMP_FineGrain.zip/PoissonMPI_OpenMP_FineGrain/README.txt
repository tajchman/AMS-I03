Code de resolution approchée de l'équation de la chaleur

Version MPI + OpenMP Grain Fin
_____________________
Pour compiler

./build.py

_____________________
Pour exécuter sur 3 processus MPI

mpirun -n 3 ./install/poisson_mpi.exe

_____________________
Ameliorer le découpage OpenMP Grain Fin
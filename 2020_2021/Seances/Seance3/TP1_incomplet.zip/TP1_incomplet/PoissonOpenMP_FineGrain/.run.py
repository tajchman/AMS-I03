resultsDir = "./results/gnu/Release"
threads = 4

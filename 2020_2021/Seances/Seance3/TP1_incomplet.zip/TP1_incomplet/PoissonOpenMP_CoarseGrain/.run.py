resultsDir = r"./results/gnu/Release"
threads = 4

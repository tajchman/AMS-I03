#define IMAX 8
void set_terms(int n);
double sinus_taylor(double x);
double sinus_machine(double x);

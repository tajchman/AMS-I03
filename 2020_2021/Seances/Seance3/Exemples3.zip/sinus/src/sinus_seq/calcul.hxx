#include <vector>

void calcul(std::vector<double> & pos,
           std::vector<double> & v1,
           std::vector<double> & v2,
           int n1, int n2);
